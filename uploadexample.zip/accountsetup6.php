<!DOCTYPE html>
<html>
    <link rel="stylesheet" media="screen and (min-width: 550px)" href="css/styles.php">
    <link rel="stylesheet" media="screen and (max-width: 550px)" href="css/400.php" />
<header>
<title>Account Setup</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<div class="titlediv">
    <?php
    $error = isset($_GET['error']) ? $_GET['error'] : null;
    ?>
</div>
</header>
<body>
<center>
<div class="photodiv">
    <?php
    if ($error == 1) {
        echo "<h2>Please Choose a Picture</h2>";
    } elseif ($error == 2) {
        echo "<h2>Image Too Large</h2>";
    }
    ?>
    <p><strong>Upload a Profile Picture</strong></p><br>
    <div class="PreviewPicture" id='image'></div>
<form id="infoform" name="infoform" method="post" action="upload.php" enctype="multipart/form-data">

<input id="FileUpload" type="file" name="ImageUpload">
<input type="submit" value="Upload Image" name="submitPhoto" id="submitPhoto">
</form>
</div>
</center>
<script>
    document.getElementById("FileUpload").onchange = function () {
        var reader = new FileReader();

        reader.onload = function (e) {
            // get loaded data and render thumbnail.
            document.getElementById("image").style.backgroundImage = "url(" + e.target.result + ")";
            
        };

        // read the image file as a data URL.
        reader.readAsDataURL(this.files[0]);
    };
    </script>
</body>
</html>
